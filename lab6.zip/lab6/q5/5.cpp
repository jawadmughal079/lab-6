#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream read("Full_name.txt");
    int counter = 0;
    int size = 70;
    int l = 0;
    int m = 0;
    char array[size];
    char sample[size];
    char sample2[size];
    char obr[size] = " ";

    read.getline(array, size);
    cout << "SENTENCE IS  : ";
    cout << array;
    cout << endl;
    obr[l++] = array[0];
    for (int i = 0; array[i] != '\0'; i++)
    {

        if (array[i] == ' ')
        {
            obr[l++] = array[i + 1];
        }
        if (array[i] == ' ')
        {
            for (int j = i; array[j] != '\0'; j++)
            {
                sample[counter++] = array[j];
            }
        }
    }
    cout << "OBBERVATION OF YOUR SENTENCE IS  :  ";
    cout << endl;
    if (l <= 1)
    {
        cout << " No  is avaliable for this sentence ";
    }
    else
    {

        for (int i = 0; i < l - 1; i++)
        {
            cout << obr[i] << "    ";
        }
        for (int k = counter - 1; sample[k] != ' '; k--)
        {

            sample2[m++] = sample[k];

        }
        for (int k = m - 1; k >= 0; k--)
        {

            cout << sample2[k];
        }
    }
    return 0;
}

// #include <iostream>
// #include <fstream>
// using namespace std;
// int lenghtFinder(char array[]);
// int main()
// {
//     const int size = 100;
//     char array1[size] = " ";
//     char store1[size] = " ";
//     char store2[size] = " ";
//     char ob[size] = " ";
//     int o = 0;
//     int l = 0;
//     int m = 0;
//     ifstream re;
//     re.open("Full_name.txt");
//     int lenght = lenghtFinder(array1);
//     if (re)
//     {
//         re.getline(array1, size);
//         ob[o++] = array1[0];
//         for (int i = 1; array1[i] != '\0'; i++)
//         {
//             if (array1[i] == ' ')
//             {
//                 ob[o++] = array1[i + 1];
//             }
//             if (array1[i] == ' ')
//             {
//                 for (int j = i; array1[j] != '\0'; j++)
//                 {
//                     store1[l++] = array1[j];
//                 }
//             }
//         }
//         for (int i = 0; i < o - 1; i++)
//         {
//             cout << ob[i] << " ";
//         }
//         for (int k = l - 1; store1[k] != ' '; k--)
//         {

//             store2[m++] = store1[k];

//         }
//     }

// return 0;
// }
// int lenghtFinder(char array[])
// {
//     int lenght = 0;
//     while (array[lenght] != '\0')
//     {
//         lenght++;
//     }
//     return lenght;
// }