#include <iostream>
using namespace std;
void palindrome(char word[], int size);
char changeCase(char storeArray[], int lenght);

void isReverse(char storeArray[], int lenght);
int main()
{

    int size = 100;

    char word[size];
    cout << "ENTER A STRING PLEASE :: ";
    cin.getline(word, size);
    palindrome(word, size);

    return 0;
}
void palindrome(char word[], int size)
{
    int lenght = 0;
    bool checker = 1;
    while (word[lenght] != '\0')
    {
        lenght++;
    }
    char sampleArray[lenght] = " ";
    for (int i = 0; i < lenght; i++)
    {
        sampleArray[i] = word[i];
    }

    for (int i = 0; word[i] != '\0'; i++)
    {

        if (word[i] != word[lenght - 1 - i])
        {
            checker = 0;
            break;
        }
    }
    if (checker == 1)
    {
        cout << "---------------------------------------------------------\n";
        cout << "\t\t\t\tPalindrome\n";
        cout << "---------------------------------------------------------\n";
        changeCase(sampleArray, lenght);
    }
    else
    {
        cout << "---------------------------------------------------------\n";
        cout << "\t\t\t\tNot-Palindrome\n";
        cout << "---------------------------------------------------------\n";
        isReverse(sampleArray, lenght);
    }
}
char changeCase(char storeArray[], int lenght)
{
    cout << endl;
    cout << "changeCase Of funtion is ::: ";

    for (int i = 0; i < lenght; i++)
    {

        if (storeArray[i] >= 'A' && storeArray[i] <= 'Z')
        {
            storeArray[i] = storeArray[i] + 32;
        }
        else
        {
            storeArray[i] = storeArray[i] - 32;
        }
    }
    for (int i = 0; i < lenght; i++)
    {
        cout << storeArray[i];
    }
    return 1;
}
void isReverse(char storeArray[], int lenght)
{
    cout << endl;
    cout << "Reverse Of funtion is ::: ";

    for (int i = lenght - 1; i >= 0; i--)
    {
        cout << storeArray[i];
    }
}