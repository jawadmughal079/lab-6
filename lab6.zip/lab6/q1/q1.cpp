
#include <iostream>
#include <fstream>
using namespace std;
fstream readFile()
{
    fstream file("data.txt", ios::in);
    return file;
}
void check(int array[], const int size, int &found, int &count)
{
    for (int i = 0; i < size; i++)
    {
        if (array[i] != 2 && array[i] % 2 == 0)
        {
            found = array[i];
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (array[i] == found)
        {
            count++;
        }
    }
}
int sum(int a , int b){
    int value = 0;
    value = a*b;
    return value;
}

int main()
{
    int found = 0, count = 0;
    const int size = 15;
    fstream f;
    f = readFile();
    int temp;
    int array[size];
    for (int i = 0; i < size; i++)
    {
        f >> temp;
        cout << temp << endl;
        array[i] = temp;
    }
    check(array, size, found, count);
    cout <<"First even number :"<< found << endl;
    cout << "Frequency of this number :"<<count<<endl;
    int value;
    value = sum(found, count);
    cout << "Sum of this number is :"<<value;

    return 0;
}
