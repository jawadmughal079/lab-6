#include <iostream>
#include <fstream>
void readfile();
int lenght(char array[]);
int check(char array[], char name[], int lenght1, int lenght2);
using namespace std;
int main()
{

    readfile();
    return 0;
}
void readfile()
{
    ifstream read("data.txt");
    int size = 100;
    int i = 0;
    int lenght1 = 0;
    int lenght2 = 0;
    char array[size] = " ";
    char name[size] = " ";
    read.getline(array, size);
    lenght1 = lenght(array);
    cout << "lenght1 :" << lenght1;
    cout << endl;
    cout<<" enter a animal you want to search : ";
    cin.getline(name, size);
    lenght2 = lenght(name);
    cout << "lenght2 : " << lenght2;
    cout << endl;
    check(array, name, lenght1, lenght2);
}
int lenght(char array[])
{
    int lenght = 0;
    while (array[lenght] != '\0')
    {
        lenght++;
    }
    return lenght;
}
int check(char array[], char name[], int lenght1, int lenght2)
{
    int k = 0;
    int j = 0;
    bool flag = 0;
    for (int i = 0; array[i] != '\0'; i++)
    {
        k = i;
        for (j = 0; name[j] != '\0'; j++)
        {
            if (array[k] != name[j])
            {
                break;
            }
            k++;
        }
        if (j == lenght2)
        {
            for (int o = i; o < i + lenght2; o++)
            {
                cout << array[o];
                flag = 1;
            }
        }
    }
    if (flag)
    {
        cout << endl;
        cout << "animal Found ";
    }
    else
    {
        cout << " animal not found ";
    }
}