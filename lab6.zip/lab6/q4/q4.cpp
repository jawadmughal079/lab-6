#include <iostream>
#include <fstream>
void removeVowels();
using namespace std;
int main()
{

    removeVowels();

    return 0;
}
void removeVowels()
{
    ifstream read("input.txt");
    char storeArray[1000] = " ";
    char ch = ' ';
    int l = 0;
    while (!read.eof())
    {
        read >> ch;
        if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u' && ch != 'A' && ch != 'E' && ch != 'I' && ch != 'O' && ch != 'U')
        {
            storeArray[l++] = ch;
        }
    }
    ofstream write("update.txt", ios::app);
    write << storeArray;
}